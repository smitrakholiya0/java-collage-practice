import mypack.Dell;
class Ac {
    public static void main(String[] args) {

        Dell obj2 = new Dell();
        obj2.show();
    }
}