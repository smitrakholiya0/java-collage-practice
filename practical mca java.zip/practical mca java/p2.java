import java.util.Scanner;

class Person {
    String name;
    String gender;

    public void input(Scanner scanner) {
        System.out.print("Enter name: ");
        name = scanner.nextLine();
        System.out.print("Enter gender: ");
        gender = scanner.nextLine();
    }

    public void output() {
        System.out.println("Name: " + name);
        System.out.println("Gender: " + gender);
    }
}

class Student extends Person {
    String department;
    String semester;

    public void input(Scanner scanner) {
        super.input(scanner);
        System.out.print("Enter department: ");
        department = scanner.nextLine();
        System.out.print("Enter semester: ");
        semester = scanner.nextLine();
    }

    public void output() {
        super.output();
        System.out.println("Department: " + department);
        System.out.println("Semester: " + semester);
    }
}

class Result extends Student {
    int[] marks = new int[3];
    int total;
    float percentage;
    char grade;

    @Override
    public void input(Scanner scanner) {
        super.input(scanner);
        for (int i = 0; i < marks.length; i++) {
            System.out.print("Enter marks for subject " + (i + 1) + ": ");
            marks[i] = scanner.nextInt();
        }
        scanner.nextLine(); // Consume leftover newline
    }

    public void calculates() {
        total = 0;
        for (int i = 0; i < marks.length; i++) {
              total += marks[i];
        }

        percentage = total / 3.0f;
        if (percentage >= 90) {
            grade = 'A';
        } else if (percentage >= 75) {
            grade = 'B';
        } else if (percentage >= 60) {
            grade = 'C';
        } else {
            grade = 'D';
        }
    }

    @Override
    public void output() {
        super.output();
        System.out.print("Marks: ");
        for (int i = 0; i < marks.length; i++) {
            System.out.print(marks[i] + " ");
            }

        System.out.println();
        System.out.println("Total: " + total);
        System.out.println("Percentage: " + percentage + "%");
        System.out.println("Grade: " + grade);
    }
}

public class p2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Result result = new Result();
        result.input(scanner);
        result.calculates();
        result.output();
        scanner.close();
    }
}
