import java.util.Scanner;
class InvalidAgeException extends Exception {
    public InvalidAgeException(String message) {
        super(message);
    }
}


class Person {
    String name;
    int age;
    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    void validateAge() throws InvalidAgeException {
        if (age < 18) {
            throw new InvalidAgeException("Age must be at least 18!");
        }
    }

    void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}

public class p4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter age: ");
        int age = scanner.nextInt();


        Person person = new Person(name, age);

        try {
            person.validateAge();
            person.displayInfo();  
        } catch (InvalidAgeException e) {
            System.out.println(e.getMessage());  
        }
    }
}
