import java.util.ArrayList;
import java.util.Scanner;

class practice1{
    public static void main(String args[]){
        ArrayList<String> names= new ArrayList<>();
        Scanner sc = new Scanner(System.in);

        for(int i=1; i<=5; i++){
            System.out.println("enetr name"+i);
            names.add(sc.nextLine());
        }
        System.out.println("all name is "+ names);


        System.out.println("enter you want to search names");
        String sr = sc.nextLine();
        System.out.println(names.indexOf(sr));

        System.out.println("enter name for add");
        names.add(sc.nextLine());
        System.out.println("all name is "+ names);

        System.out.println("enter index for update");
        int ind= sc.nextInt();
        sc.nextLine();

        System.out.println("enter name");
        String uname= sc.nextLine();
        names.set(ind, uname);
        System.out.println("all name is "+ names);

        System.out.println("enter index for delete");
        names.remove(sc.nextInt());



        System.out.println("all name is "+ names);
    }
}





// import java.util.Scanner;
// class Person{
//     String name;
//     String gender;

//     void input(){
//         Scanner sc = new Scanner(System.in);
//         System.out.println("enter name");
//         name = sc.nextLine();
//         System.out.println("enter gender");
//         gender = sc.nextLine();
//     }

//     void output(){
//         System.out.println("name is "+name);
//         System.out.println("gender is "+gender);
//     }
// }

// class Student extends Person{
//     String department;
//     String semester;

//     void input(){
//         super.input();
//         Scanner sc = new Scanner(System.in);
//         System.out.println("enter department");
//         department = sc.nextLine();
//         System.out.println("enter semestser");
//         semester = sc.nextLine();
//     }
//     void output(){
//         super.output();
//         System.out.println("department is "+department);
//         System.out.println("semester is "+semester);
//     }

// }

// class Result extends Student{
//     int[] marks = new int[3];
//     int total;
//     float percentage;
//     char grade;

//     void input(){
//         super.input();
//         Scanner sc = new Scanner(System.in);
//         for(int i=0; i<3; i++){
//             System.out.println("enter mark of sub "+(i+1));
//             marks[i]= sc.nextInt();
//         }
//     }

//     void calculate(){
//         total=0;
//         for(int i=0; i<3; i++){
//            total+= marks[i];
//         }
//         percentage = total/3f;
        
//         if(percentage>90){
//             grade='A';
//         }
//         else if(percentage>80){
//             grade='B';
//         }
//         else if(percentage>70){
//             grade='C';
//         }
//         else{
//             grade='D';
//         }
//     }

//     void output(){
        
//         super.output();
//         // total=0;
//         for (int i=0; i<3; i++) {
//             System.out.print(marks[i] + " ");
//         }

//         System.out.println();
//         System.out.println("Total: " + total);
//         System.out.println("Percentage: " + percentage + "%");
//         System.out.println("Grade: " + grade);
//     }
// }

// class practice1{
//     public static void main(String args[]){
//         Result ob = new Result();
//         ob.input();
//         ob.calculate();
//         ob.output();
//     }
// }


// abstract class BankAccount{
//     String accountHolder;
//     float balance;

//     void displayAccountDetails(){
//         System.out.println("Account holder name "+accountHolder);
//         System.out.println("Account balance "+balance);
//     }

//     abstract void calculateInterest();
// }

// class SavingsAccount extends BankAccount{
//     SavingsAccount(String accountHolder, float balance){
//         this.accountHolder= accountHolder;
//         this.balance= balance;
//     }
//         void calculateInterest() {
//         System.out.println("Interest on Savings Account: " + (balance * 0.04));
//     }
// }

// class CurrentAccount extends BankAccount {
//     CurrentAccount(String accountHolder, float balance) {
//         this.accountHolder = accountHolder;
//         this.balance = balance;
//     }

//     void calculateInterest() {
//         System.out.println("Interest on Current Account: " + (balance * 0.02));
//     }
// }

// class practice1{
//     public static void main(String[] args) {
//         BankAccount savings = new SavingsAccount("smit", 4000);
//         BankAccount current = new CurrentAccount("patel", 5000);

//         savings.calculateInterest();
//         savings.displayAccountDetails();

//         current.calculateInterest();
//         current.displayAccountDetails();


//     }
// }



// import java.util.Scanner;
// class InvalidAgeException extends Exception{
//     InvalidAgeException(String message){
//         super(message);
//     }
// }

// class Person{
//     String name;
//     int age;
//     Person(String name, int age){
//         this.name=name;
//         this.age=age;
//     }
    
//     void validateAge()throws InvalidAgeException{
//         if(age<18){
//             throw new InvalidAgeException("enter valid age");
//         }
//     }

//     void displayInfo(){
//         System.out.println("Name: " + name);
//         System.out.println("Age: " + age);
//     }
// }

// class practice1{
//     public static void main(String args[]){
//         Scanner sc = new Scanner(System.in);
//         System.out.print("Enter name: ");
//         String name = sc.nextLine();
//         System.out.print("Enter age: ");
//         int age = sc.nextInt();

//         Person p= new Person(name, age);

//         try{
//             p.validateAge();
//             p.displayInfo();
//         }
//         catch(InvalidAgeException e){
//             System.out.println(e); 
//         }
//     }
// }