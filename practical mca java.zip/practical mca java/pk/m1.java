import mypack.Hp;
import mypack.Dell;
class m1{
    public static void main(String args[]){
        Hp h= new Hp();
        Dell d= new Dell();

        h.displayHp();
        d.displayDell();
    }
}