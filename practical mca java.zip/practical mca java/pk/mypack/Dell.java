package mypack;
public class Dell{
    public void displayDell(){
        System.out.println("This is a Dell");
    }
}