package mypack;
public class Hp{
    public void displayHp(){
        System.out.println("This is a Hp");
    }
}