import java.util.HashSet;
import java.util.Scanner;


public class p1HashSet {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        HashSet<String> names = new HashSet<>();

        // Input names
        System.out.println("Enter 5 names:");
        for (int i = 0; i < 5; i++) {
            System.out.print("Enter name: ");
            String name = sc.nextLine();
            if (!names.add(name)) {
                System.out.println("Duplicate names are not allowed. Try again.");
                i--; // Retry the same iteration for a unique name
            }
        }

        // Display names
        System.out.println("Names: " + names);

        // Search for a name
        System.out.print("Enter name to search: ");
        String searchName = sc.nextLine();
        if (names.contains(searchName)) {
            System.out.println(searchName + " is in the list.");
        } else {
            System.out.println(searchName + " is not in the list.");
        }

        // Add a name
        System.out.print("Enter a new name to add: ");
        String newName = sc.nextLine();
        if (names.add(newName)) {
            System.out.println(newName + " added successfully.");
        } else {
            System.out.println(newName + " is already in the list.");
        }
        System.out.println("Updated list: " + names);

        // Remove a name
        System.out.print("Enter a name to remove: ");
        String removeName = sc.nextLine();
        if (names.remove(removeName)) {
            System.out.println(removeName + " removed successfully.");
        } else {
            System.out.println(removeName + " is not in the list.");
        }
        System.out.println("Updated list: " + names);

        // Display all names

System.out.println("All names:");
String[] nameArray = names.toArray(new String[0]); // Convert HashSet to an array
for (int i = 0; i < nameArray.length; i++) {
    System.out.println("Position " + (i + 1) + ": " + nameArray[i]);
}


        sc.close();
    }
}
