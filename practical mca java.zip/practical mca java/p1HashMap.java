import java.util.HashMap;
import java.util.Scanner;

public class p1HashMap {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        HashMap<Integer, String> names = new HashMap<>();

        // Input names
        System.out.println("Enter 5 names:");
        for (int i = 1; i <= 5; i++) {
            System.out.print("Enter name: ");
            names.put(i, sc.nextLine());
        }

        // Display names
        System.out.println("Names: " + names);

        // Search for a name
        System.out.print("Enter name to search: ");
        String searchName = sc.nextLine();
        if (names.containsValue(searchName)) {
            for (int i = 0; i < names.size(); i++) {
                if (names.get(i).equals(searchName)) {
                System.out.println(searchName + " is at position " + i);
                break;
    }
}

        } else {
            System.out.println(searchName + " is not in the list.");
        }

        // Add a name
        System.out.print("Enter a new name to add: ");
        names.put(names.size() + 1, sc.nextLine());
        System.out.println("Updated list: " + names);

        // Update the third name
        if (names.size() >= 3) {
            System.out.println("Current third name: " + names.get(3));
            System.out.print("Enter new name for position 3: ");
            names.put(3, sc.nextLine());
            System.out.println("After updating the third name: " + names);
        }

        // Remove the fourth name
        if (names.size() >= 4) {
            names.remove(4);
            System.out.println("After removing the fourth name: " + names);
        }

        // Display all names
System.out.println("All names:");
Object[] keys = names.keySet().toArray(); // Convert keys to an array
for (int i = 0; i < keys.length; i++) {
    int key = (int) keys[i]; // Cast each key to an integer
    System.out.println("Position " + key + ": " + names.get(key));
}


        sc.close();
    }
}
