// Interface Exam
interface Exam {
    // Method to check if a student passed based on marks
    boolean Pass(int mark);
}

// Interface Classify
interface Classify {
    // Method to classify the division based on average marks
    String Division(int average);
}

// Class Result that implements both Exam and Classify interfaces
class Result implements Exam, Classify {
    // Implementing the Pass method from Exam interface
    @Override
    public boolean Pass(int mark) {
        return mark >= 50;  // Pass if mark is 50 or more, else fail
    }

    // Implementing the Division method from Classify interface
    @Override
    public String Division(int average) {
        if (average >= 60) {
            return "First";
        } else if (average >= 50) {
            return "Second";
        } else {
            return "No division";
        }
    }

    // Method to calculate the average of marks
    public int calculateAverage(int[] marks) {
        int total = 0;
        for (int mark : marks) {
            total += mark;
        }
        return total / marks.length;  // Return the average
    }
}

public class ExamResult {

    public static void main(String[] args) {
        // Create an object of Result class
        Result result = new Result();

        // Example marks for a student
        int[] marks = {70, 55, 80, 45, 65};  // Array of marks

        // Calculate average marks
        int average = result.calculateAverage(marks);

        // Check if the student passed
        boolean isPassed = result.Pass(average);  // Check pass status based on average marks

        // Classify division based on average marks
        String division = result.Division(average);

        // Output the results
        System.out.println("Average Marks: " + average);
        System.out.println("Pass Status: " + (isPassed ? "Passed" : "Failed"));
        System.out.println("Division: " + division);
    }
}
