// Abstract class Shape
abstract class Shape {
    // Abstract method area() to be implemented by subclasses
    public abstract double area();
}

// Subclass Triangle
class Triangle extends Shape {
    private double base;
    private double height;

    // Constructor to initialize base and height
    public Triangle(double base, double height) {
        this.base = base;
        this.height = height;
    }

    // Overriding the area() method to calculate the area of a triangle
    @Override
    public double area() {
        return 0.5 * base * height;  // Area formula for triangle
    }
}

// Subclass Rectangle
class Rectangle extends Shape {
    private double length;
    private double width;

    // Constructor to initialize length and width
    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    // Overriding the area() method to calculate the area of a rectangle
    @Override
    public double area() {
        return length * width;  // Area formula for rectangle
    }
}

// Subclass Circle
class Circle extends Shape {
    private double radius;

    // Constructor to initialize the radius
    public Circle(double radius) {
        this.radius = radius;
    }

    // Overriding the area() method to calculate the area of a circle
    @Override
    public double area() {
        return Math.PI * radius * radius;  // Area formula for circle
    }
}

// Main class to test the implementation
public class ShapeTest {

    public static void main(String[] args) {
        // Create objects of Triangle, Rectangle, and Circle
        Shape triangle = new Triangle(5, 10);   // Base = 5, Height = 10
        Shape rectangle = new Rectangle(4, 6);   // Length = 4, Width = 6
        Shape circle = new Circle(7);             // Radius = 7

        // Display the area of each shape
        System.out.println("Area of Triangle: " + triangle.area());
        System.out.println("Area of Rectangle: " + rectangle.area());
        System.out.println("Area of Circle: " + circle.area());
    }
}
