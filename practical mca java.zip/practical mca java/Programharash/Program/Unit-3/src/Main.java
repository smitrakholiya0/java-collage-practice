import student.Student;
import exam.Result;

public class Main {
    public static void main(String[] args) {
        // Create a Student object
        int[] marks = {75, 85, 90, 80, 95};  // Example marks
        Student student = new Student("John Doe", 101, marks);
        
        // Create Result object to generate mark sheet
        Result result = new Result();
        result.generateMarkSheet(student);
    }
}
