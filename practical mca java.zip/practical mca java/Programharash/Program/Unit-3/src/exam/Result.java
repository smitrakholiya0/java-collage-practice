package exam;

import student.Student;

public class Result {

    // Method to calculate total marks
    public int calculateTotalMarks(int[] marks) {
        int total = 0;
        for (int mark : marks) {
            total += mark;
        }
        return total;
    }

    // Method to calculate average marks
    public double calculateAverage(int[] marks) {
        int total = calculateTotalMarks(marks);
        return total / (double) marks.length;
    }

    // Method to determine division based on average marks
    public String calculateDivision(double average) {
        if (average >= 60) {
            return "First Division";
        } else if (average >= 50) {
            return "Second Division";
        } else if (average >= 40) {
            return "Third Division";
        } else {
            return "Fail";
        }
    }

    // Method to generate the mark sheet
    public void generateMarkSheet(Student student) {
        System.out.println("Mark Sheet for Student: " + student.getName());
        System.out.println("Student ID: " + student.getStudentId());
        
        int[] marks = student.getMarks();
        int totalMarks = calculateTotalMarks(marks);
        double averageMarks = calculateAverage(marks);
        String division = calculateDivision(averageMarks);

        System.out.println("Total Marks: " + totalMarks);
        System.out.println("Average Marks: " + averageMarks);
        System.out.println("Division: " + division);
    }
}
