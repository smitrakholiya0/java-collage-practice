class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class ExceptionHandlingDemo {
    public static void main(String[] args) {
        try {
            performOperation();
        } catch (CustomException e) {
            System.out.println("Caught CustomException: " + e.getMessage());
        } catch (ArithmeticException e) {
            System.out.println("Caught ArithmeticException: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Caught General Exception: " + e.getMessage());
        } finally {
            System.out.println("First try-catch block executed.");
        }

        try {
            int result = 10 / 0; // This will throw ArithmeticException
        } catch (ArithmeticException e) {
            System.out.println("Caught ArithmeticException in second try block: " + e.getMessage());
        } finally {
            System.out.println("Second try-catch block executed.");
        }
    }

    public static void performOperation() throws CustomException {
        try {
            throwCustomException();
        } catch (CustomException e) {
            System.out.println("Caught CustomException in performOperation method: " + e.getMessage());
            throw e; // rethrowing the exception
        } finally {
            System.out.println("Finally block in performOperation method executed.");
        }
    }

    public static void throwCustomException() throws CustomException {
        throw new CustomException("This is a custom exception.");
    }
}
