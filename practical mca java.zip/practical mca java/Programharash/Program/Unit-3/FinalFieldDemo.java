class Employee {
    // Final field declaration
    final int emp_id;  // Final instance variable
    final String emp_name;  // Final instance variable

    // Constructor to initialize final fields
    public Employee(int emp_id, String emp_name) {
        this.emp_id = emp_id;
        this.emp_name = emp_name;
    }

    // Method to display employee details
    public void displayEmployeeDetails() {
        System.out.println("Employee ID: " + emp_id);
        System.out.println("Employee Name: " + emp_name);
    }
}

public class FinalFieldDemo {

    public static void main(String[] args) {
        // Creating an object of Employee class
        Employee employee = new Employee(101, "John Doe");

        // Accessing the final fields through the object
        System.out.println("Accessing final fields through the object:");
        employee.displayEmployeeDetails();

        // Attempting to modify the final fields (will give an error)
        // Uncommenting the following lines will cause a compilation error:
        // employee.emp_id = 102;  // Error: cannot assign a value to final variable emp_id
        // employee.emp_name = "Jane Doe";  // Error: cannot assign a value to final variable emp_name

        // You cannot modify the final fields, but they can be used in calculations or logic as read-only.
    }
}
