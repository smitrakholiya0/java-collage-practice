public class StringMethodsExample {
    public static void main(String[] args) {

        String str1 = "Hello, World!";
        String str2 = "java programming";
        
        // 1. length() - Returns the length of the string
        System.out.println("Length of str1: " + str1.length());

        // 2. charAt() - Returns the character at the specified index
        System.out.println("Character at index 7 of str1: " + str1.charAt(7));

        // 3. substring() - Returns a substring starting from index 'start' (inclusive) to 'end' (exclusive)
        System.out.println("Substring of str1 from index 7: " + str1.substring(7));
        System.out.println("Substring of str1 from index 0 to 5: " + str1.substring(0, 5));

        // 4. toLowerCase() - Converts all characters of the string to lowercase
        System.out.println("str2 in lowercase: " + str2.toLowerCase());

        // 5. toUpperCase() - Converts all characters of the string to uppercase
        System.out.println("str2 in uppercase: " + str2.toUpperCase());

        // 6. equals() - Compares two strings for equality
        String str3 = "Hello, World!";
        System.out.println("str1 equals str3: " + str1.equals(str3));

        // 7. equalsIgnoreCase() - Compares two strings, ignoring case
        String str4 = "JAVA PROGRAMMING";
        System.out.println("str2 equalsIgnoreCase str4: " + str2.equalsIgnoreCase(str4));

        // 8. trim() - Removes leading and trailing whitespace from the string
        String str5 = "   Hello, World!   ";
        System.out.println("str5 after trim: '" + str5.trim() + "'");

        // 9. indexOf() - Returns the index of the first occurrence of the specified character or substring
        System.out.println("Index of 'World' in str1: " + str1.indexOf("World"));

        // 10. replace() - Replaces all occurrences of a specified character or substring with a new one
        System.out.println("Replace 'World' with 'Java' in str1: " + str1.replace("World", "Java"));

        // 11. contains() - Checks if the string contains the specified character or substring
        System.out.println("Does str1 contain 'Hello'? " + str1.contains("Hello"));

        // 12. startsWith() - Checks if the string starts with the specified prefix
        System.out.println("Does str1 start with 'Hello'? " + str1.startsWith("Hello"));

        // 13. endsWith() - Checks if the string ends with the specified suffix
        System.out.println("Does str1 end with '!': " + str1.endsWith("!"));

        // 14. split() - Splits the string into an array of substrings based on the delimiter
        String[] words = str1.split(" ");
        System.out.println("Words in str1: ");
        for (String word : words) {
            System.out.println(word);
        }

        // 15. concat() - Concatenates the specified string to the end of the current string
        String str6 = "Java";
        System.out.println("Concatenated string: " + str6.concat(" Programming"));

        // 16. valueOf() - Converts different types (int, boolean, etc.) to their string representation
        int number = 123;
        System.out.println("String representation of number: " + String.valueOf(number));
    }
}
