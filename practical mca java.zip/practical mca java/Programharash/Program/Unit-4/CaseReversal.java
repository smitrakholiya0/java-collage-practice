import java.util.Scanner;

public class CaseReversal {

    // Method to check and reverse the case of a string
    public static String reverseCase(String str) {
        StringBuilder result = new StringBuilder();

        // Loop through each character of the string
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);

            // If the character is lowercase, convert to uppercase
            if (Character.isLowerCase(ch)) {
                result.append(Character.toUpperCase(ch));
            }
            // If the character is uppercase, convert to lowercase
            else if (Character.isUpperCase(ch)) {
                result.append(Character.toLowerCase(ch));
            }
            // If the character is not a letter, leave it unchanged
            else {
                result.append(ch);
            }
        }

        return result.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Accepting user input
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

        // Check if the input is in upper case or lower case
        if (input.equals(input.toUpperCase())) {
            System.out.println("The string is in Uppercase.");
        } else if (input.equals(input.toLowerCase())) {
            System.out.println("The string is in Lowercase.");
        } else {
            System.out.println("The string is in Mixed case.");
        }

        // Reverse the case of the string and display the result
        String reversedCaseString = reverseCase(input);
        System.out.println("String after reversing the case: " + reversedCaseString);
        
        scanner.close();
    }
}
