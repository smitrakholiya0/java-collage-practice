// Generic class Number_1
class Number_1<T extends Number> {
    private T value;

    // Constructor to initialize the value
    public Number_1(T value) {
        this.value = value;
    }

    // Method to get the value
    public T getValue() {
        return value;
    }

    // Method to display the value
    public void display() {
        System.out.println("Value: " + value);
    }

    // Method to add two values of type T (either Integer or Float)
    @SuppressWarnings("unchecked")
    public T add(Number_1<T> other) {
        if (value instanceof Integer) {
            return (T) Integer.valueOf(value.intValue() + other.getValue().intValue());
        } else if (value instanceof Float) {
            return (T) Float.valueOf(value.floatValue() + other.getValue().floatValue());
        }
        return null;
    }
}

public class Main {
    public static void main(String[] args) {
        // Creating an instance for int
        Number_1<Integer> intObj = new Number_1<>(10);
        intObj.display();

        // Creating an instance for float
        Number_1<Float> floatObj = new Number_1<>(5.5f);
        floatObj.display();

        // Adding two Integer values
        Integer sumInt = intObj.add(new Number_1<>(20));
        System.out.println("Sum of Integer values: " + sumInt.byteValue());

        // Adding two Float values
        Float sumFloat = floatObj.add(new Number_1<>(4.5f));
        System.out.println("Sum of Float values: " + sumFloat.byteValue());
    }
}
