import java.util.*;

// Customer class definition
class Customer {
    String bill_no;
    String cust_mobile_no;
    String[] item_name;
    double[] item_unit_price;
    int[] item_count;
    double total_price;

    // Constructor
    public Customer(String bill_no, String cust_mobile_no, String[] item_name, double[] item_unit_price, int[] item_count) {
        this.bill_no = bill_no;
        this.cust_mobile_no = cust_mobile_no;
        this.item_name = item_name;
        this.item_unit_price = item_unit_price;
        this.item_count = item_count;
        calculateTotalPrice();  // Calculate total price when object is created
    }

    // Method to calculate total price
    public void calculateTotalPrice() {
        total_price = 0;
        for (int i = 0; i < item_name.length; i++) {
            total_price += item_unit_price[i] * item_count[i];  // total price = unit price * quantity
        }
    }

    @Override
    public String toString() {
        StringBuilder itemDetails = new StringBuilder();
        for (int i = 0; i < item_name.length; i++) {
            itemDetails.append(item_name[i]).append(" (").append(item_count[i]).append(" units) ");
        }
        return "Bill No: " + bill_no + ", Mobile No: " + cust_mobile_no + ", Items: " + itemDetails + ", Total Price: " + total_price;
    }
}

public class CustomerHashMap {

    public static void main(String[] args) {
        // Create a HashMap to store Customer objects with the mobile number as the key
        HashMap<String, Customer> customerMap = new HashMap<>();

        // Add some customer data to the HashMap
        customerMap.put("9876543210", new Customer("B001", "9876543210", new String[] {"Apple", "Banana", "Orange"}, new double[] {50.0, 30.0, 20.0}, new int[] {5, 3, 7}));
        customerMap.put("9123456789", new Customer("B002", "9123456789", new String[] {"Laptop", "Mouse"}, new double[] {50000.0, 1500.0}, new int[] {1, 2}));
        customerMap.put("9345678901", new Customer("B003", "9345678901", new String[] {"Shirt", "Jeans", "Jacket"}, new double[] {500.0, 800.0, 1200.0}, new int[] {2, 1, 1}));

        // Display the entire HashMap
        System.out.println("Customer HashMap:");
        displayCustomerMap(customerMap);

        // Search for a customer's bill based on mobile number
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter customer mobile number to search for the bill: ");
        String mobileNo = scanner.nextLine();

        // Search and display the bill details for the given mobile number
        searchCustomerBill(customerMap, mobileNo);

        scanner.close();
    }

    // Method to display all customer details in the HashMap
    public static void displayCustomerMap(HashMap<String, Customer> customerMap) {
        for (Map.Entry<String, Customer> entry : customerMap.entrySet()) {
            System.out.println(entry.getValue());
        }
    }

    // Method to search and display a customer's bill based on mobile number
    public static void searchCustomerBill(HashMap<String, Customer> customerMap, String mobileNo) {
        if (customerMap.containsKey(mobileNo)) {
            Customer customer = customerMap.get(mobileNo);
            System.out.println("Bill details for Mobile No: " + mobileNo);
            System.out.println(customer);
        } else {
            System.out.println("No customer found with mobile number " + mobileNo);
        }
    }
}
