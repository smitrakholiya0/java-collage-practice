import java.util.*;

// A generic class with a method to count elements based on a property
public class GenericCount {

    // 1. Method to count elements satisfying a given property
    public static <T> int countProperty(Collection<T> collection, PropertyChecker<T> checker) {
        int count = 0;
        for (T element : collection) {
            if (checker.check(element)) {
                count++;
            }
        }
        return count;
    }

    public static void main(String[] args) {
        // 1. Count odd integers in a list
        List<Integer> integers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        System.out.println("Count of odd integers: " + countProperty(integers, new OddChecker()));

        // 2. Count prime numbers in a list
        List<Integer> numbers = Arrays.asList(2, 3, 4, 5, 6, 7, 8, 9, 10, 11);
        System.out.println("Count of prime numbers: " + countProperty(numbers, new PrimeChecker()));

        // 3. Count palindromes in a list of strings
        List<String> strings = Arrays.asList("madam", "racecar", "hello", "world", "level");
        System.out.println("Count of palindromes: " + countProperty(strings, new PalindromeChecker()));
    }
}

// Interface for checking a property of a generic element
interface PropertyChecker<T> {
    boolean check(T element);
}

// 2. PropertyChecker for odd integers
class OddChecker implements PropertyChecker<Integer> {
    @Override
    public boolean check(Integer element) {
        return element % 2 != 0;
    }
}

// 3. PropertyChecker for prime numbers
class PrimeChecker implements PropertyChecker<Integer> {
    @Override
    public boolean check(Integer element) {
        if (element < 2) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(element); i++) {
            if (element % i == 0) {
                return false;
            }
        }
        return true;
    }
}

// 4. PropertyChecker for palindromes (for strings)
class PalindromeChecker implements PropertyChecker<String> {
    @Override
    public boolean check(String element) {
        String reversed = new StringBuilder(element).reverse().toString();
        return element.equals(reversed);
    }
}
