import java.util.*;

// A generic class to handle sorting operations
public class GenericSort {

    // 1. Sorting a list according to the natural ordering of elements
    public static <T extends Comparable<T>> void sortList(List<T> list) {
        Collections.sort(list);
        System.out.println("Sorted List (Natural Order): " + list);
    }

    // 2. Sorting a list in reverse order
    public static <T extends Comparable<T>> void sortListReverse(List<T> list) {
        Collections.sort(list, Collections.reverseOrder());
        System.out.println("Sorted List (Reverse Order): " + list);
    }

    // 3. Sorting a list whose elements are of a custom type
    public static void sortCustomTypeList() {
        List<Person> people = new ArrayList<>();
        people.add(new Person("Alice", 30));
        people.add(new Person("Bob", 25));
        people.add(new Person("Charlie", 35));

        // Sorting by age (natural ordering since Person implements Comparable)
        Collections.sort(people);
        System.out.println("Sorted by Age (Natural Order): " + people);
    }

    // 4. Sorting a list using a Comparator
    public static void sortWithComparator() {
        List<Person> people = new ArrayList<>();
        people.add(new Person("Alice", 30));
        people.add(new Person("Bob", 25));
        people.add(new Person("Charlie", 35));

        // Sorting by name using a Comparator
        people.sort(new NameComparator());
        System.out.println("Sorted by Name (using Comparator): " + people);
    }

    public static void main(String[] args) {
        // Demonstrating sorting with numbers
        List<Integer> intList = new ArrayList<>(Arrays.asList(10, 2, 30, 4, 50));
        sortList(intList);
        sortListReverse(intList);

        // Sorting a list of custom type (Person)
        sortCustomTypeList();

        // Sorting using Comparator for custom type
        sortWithComparator();
    }
}

// A custom class that implements Comparable
class Person implements Comparable<Person> {
    String name;
    int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Overriding compareTo method for natural ordering based on age
    @Override
    public int compareTo(Person other) {
        return Integer.compare(this.age, other.age); // Sorting by age
    }

    @Override
    public String toString() {
        return "Person{name='" + name + "', age=" + age + "}";
    }
}

// Comparator for sorting by name
class NameComparator implements Comparator<Person> {
    @Override
    public int compare(Person p1, Person p2) {
        return p1.name.compareTo(p2.name); // Sorting by name
    }
}
