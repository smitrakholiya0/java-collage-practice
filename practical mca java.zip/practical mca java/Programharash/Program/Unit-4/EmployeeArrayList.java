import java.util.*;

// Employee class definition
class Employee {
    int emp_code;
    String emp_name;
    double basic_sal;
    double gross_sal;

    // Constructor
    public Employee(int emp_code, String emp_name, double basic_sal) {
        this.emp_code = emp_code;
        this.emp_name = emp_name;
        this.basic_sal = basic_sal;
        calculateGrossSal();  // Calculate gross salary when object is created
    }

    // Method to calculate gross salary
    public void calculateGrossSal() {
        // Gross salary = basic salary + 20% of basic salary (MA) + 30% of basic salary (HRA)
        this.gross_sal = basic_sal + (0.20 * basic_sal) + (0.30 * basic_sal);
    }

    @Override
    public String toString() {
        return "Employee[emp_code=" + emp_code + ", emp_name='" + emp_name + "', basic_sal=" + basic_sal + ", gross_sal=" + gross_sal + "]";
    }
}

public class EmployeeArrayList {

    public static void main(String[] args) {
        // Create an ArrayList to store Employee objects
        ArrayList<Employee> employeeList = new ArrayList<>();

        // Add some employees to the list
        employeeList.add(new Employee(101, "Alice", 50000));
        employeeList.add(new Employee(102, "Bob", 60000));
        employeeList.add(new Employee(103, "Charlie", 55000));

        // Display the ArrayList before insertion
        System.out.println("Employee List before insertion:");
        displayEmployeeList(employeeList);

        // Insert a new employee at a specific position in the ArrayList
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the position to insert the new employee (0 to " + employeeList.size() + "): ");
        int position = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character after integer input
        System.out.print("Enter Employee Code: ");
        int emp_code = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character
        System.out.print("Enter Employee Name: ");
        String emp_name = scanner.nextLine();
        System.out.print("Enter Basic Salary: ");
        double basic_sal = scanner.nextDouble();

        Employee newEmployee = new Employee(emp_code, emp_name, basic_sal);

        // Insert the new employee at the specified position
        employeeList.add(position, newEmployee);

        // Display the updated list
        System.out.println("\nEmployee List after insertion:");
        displayEmployeeList(employeeList);

        scanner.close();
    }

    // Method to display the employee list
    public static void displayEmployeeList(ArrayList<Employee> employeeList) {
        for (Employee emp : employeeList) {
            System.out.println(emp);
        }
    }
}
