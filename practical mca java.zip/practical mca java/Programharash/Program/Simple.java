// Simple Program in Java

public class Simple
{
   public static void main(String args[])
   {
     System.out.println("Harsh Rakholiya");

   }
 
}