class PrintTask implements Runnable {
    private final String character;
    private final int count;

    public PrintTask(String character, int count) {
        this.character = character;
        this.count = count;
    }

    @Override
    public void run() {
        for (int i = 0; i < count; i++) {
            System.out.print(character);
        }
    }
}

public class MultiThreadPrinting {
    public static void main(String[] args) {
        Thread threadA = new Thread(new PrintTask("A", 20));
        Thread threadB = new Thread(new PrintTask("B", 30));
        Thread threadC = new Thread(new PrintTask("C", 15));

        threadA.start();
        threadB.start();
        threadC.start();
    }
}
