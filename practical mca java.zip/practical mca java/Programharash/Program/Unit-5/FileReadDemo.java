import java.io.*;
import java.util.Scanner;

public class FileReadDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the file path to read its contents: ");
        String filePath = scanner.nextLine();

        File file = new File(filePath);

        if (file.exists() && file.isFile()) {
            int lineCount = 0;
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                System.out.println("Contents of the file:");
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println(line);
                    lineCount++;
                }
                System.out.println("\nTotal number of lines: " + lineCount);
            } catch (IOException e) {
                System.out.println("An error occurred while reading the file: " + e.getMessage());
            }
        } else {
            System.out.println("The specified file does not exist or is not a file.");
        }

        scanner.close();
    }
}
