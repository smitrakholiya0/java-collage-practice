class MyRunnable implements Runnable {

    @Override
    public void run() {
        System.out.println("Thread is running: " + Thread.currentThread().getName());
    }
}

public class ThreadingRunnable {

    public static void main(String[] args) {
        MyRunnable runnable = new MyRunnable();

        // Create two threads using the Runnable object
        Thread thread1 = new Thread(runnable, "Thread 1");
        Thread thread2 = new Thread(runnable, "Thread 2");

        // Start the threads
        thread1.start();
        thread2.start();
    }
}