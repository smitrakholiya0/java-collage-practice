class NumberPrinter {
    private final Object lock = new Object();
    private boolean isEvenTurn = true;

    public void printEven(int number) {
        synchronized (lock) {
            while (!isEvenTurn) {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    e.printStackTrace();
                }
            }
            System.out.println("Even: " + number);
            isEvenTurn = false;
            lock.notifyAll();
        }
    }

    public void printOdd(int number) {
        synchronized (lock) {
            while (isEvenTurn) {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    e.printStackTrace();
                }
            }
            System.out.println("Odd: " + number);
            isEvenTurn = true;
            lock.notifyAll();
        }
    }
}

public class OddEvenThreads {
    public static void main(String[] args) {
        NumberPrinter numberPrinter = new NumberPrinter();

        Thread evenThread = new Thread(() -> {
            for (int i = 2; i <= 50; i += 2) {
                numberPrinter.printEven(i);
            }
        });

        Thread oddThread = new Thread(() -> {
            for (int i = 1; i <= 49; i += 2) {
                numberPrinter.printOdd(i);
            }
        });

        evenThread.start();
        oddThread.start();
    }
}