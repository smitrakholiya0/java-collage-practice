class Account {
    private int balance;

    public Account(int balance) {
        this.balance = balance;
    }

    public synchronized void deposit(int amount) {
        balance += amount;
        System.out.println(Thread.currentThread().getName() + " deposited " + amount + ", Balance: " + balance);
    }

    public synchronized void withdraw(int amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println(Thread.currentThread().getName() + " withdrew " + amount + ", Balance: " + balance);
        } else {
            System.out.println(Thread.currentThread().getName() + " attempted to withdraw " + amount + ", Insufficient Balance");
        }
    }

    public int getBalance() {
        return balance;
    }
}

class AccountTask implements Runnable {
    private final Account account;
    private final boolean deposit;
    private final int amount;

    public AccountTask(Account account, boolean deposit, int amount) {
        this.account = account;
        this.deposit = deposit;
        this.amount = amount;
    }

    @Override
    public void run() {
        if (deposit) {
            account.deposit(amount);
        } else {
            account.withdraw(amount);
        }
    }
}

public class AccountSynchronizationDemo {
    public static void main(String[] args) {
        Account account = new Account(100);

        Thread thread1 = new Thread(new AccountTask(account, true, 50), "Thread-1");
        Thread thread2 = new Thread(new AccountTask(account, false, 30), "Thread-2");
        Thread thread3 = new Thread(new AccountTask(account, false, 80), "Thread-3");

        thread1.start();
        thread2.start();
        thread3.start();
    }
}
