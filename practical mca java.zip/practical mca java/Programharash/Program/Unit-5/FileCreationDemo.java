import java.io.*;
import java.util.Scanner;

public class FileCreationDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the file path to create a new file: ");
        String filePath = scanner.nextLine();

        File file = new File(filePath);

        try {
            if (file.createNewFile()) {
                System.out.println("File created successfully at: " + file.getAbsolutePath());
            } else {
                System.out.println("File already exists at: " + file.getAbsolutePath());
            }
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file: " + e.getMessage());
        }

        scanner.close();
    }
}
