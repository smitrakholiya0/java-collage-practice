import java.util.Scanner;

public class InputStreamDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter your name: ");
        String name = scanner.nextLine();

        System.out.println("Enter your age: ");
        int age = scanner.nextInt();

        System.out.println("Enter your favorite number: ");
        double favoriteNumber = scanner.nextDouble();

        System.out.println("\nUser Input Summary:");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Favorite Number: " + favoriteNumber);

        scanner.close();
    }
}
