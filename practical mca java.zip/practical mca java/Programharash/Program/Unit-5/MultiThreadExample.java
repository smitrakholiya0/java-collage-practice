public class MultiThreadExample {

    public static void main(String[] args) {
        // Create Thread1
        Thread thread1 = new Thread(() -> {
            try {
                while (true) {
                    System.out.println("Thread1");
                    Thread.sleep(2000); // Sleep for 2000 milliseconds
                }
            } catch (InterruptedException e) {
                System.out.println("Thread1 interrupted");
            }
        });

        // Create Thread2
        Thread thread2 = new Thread(() -> {
            try {
                while (true) {
                    System.out.println("Thread2");
                    Thread.sleep(4000); // Sleep for 4000 milliseconds
                }
            } catch (InterruptedException e) {
                System.out.println("Thread2 interrupted");
            }
        });

        // Start both threads
        thread1.start();
        thread2.start();
    }
}
