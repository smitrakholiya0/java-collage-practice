public class Student {
    // Instance variables
    private int enrollmentNo;
    private String name;
    private String gender;
    private int marks;

    // Static variable to count the number of objects
    private static int count = 0;

    // Constructor to initialize instance variables
    public Student(int enrollmentNo, String name, String gender) {
        this(enrollmentNo, name, gender, 0); // Constructor chaining
    }

    public Student(int enrollmentNo, String name, String gender, int marks) {
        this.enrollmentNo = enrollmentNo;
        this.name = name;
        this.gender = gender;
        this.marks = marks;
        count++; // Increment static count variable
    }

    // Display method to show the details of the student
    public void display() {
        System.out.println("Enrollment No: " + enrollmentNo);
        System.out.println("Name: " + name);
        System.out.println("Gender: " + gender);
        System.out.println("Marks: " + marks);
    }

    // Static method to get the count of objects
    public static int getCount() {
        return count;
    }

    // Main method to demonstrate functionality
    public static void main(String[] args) {
        Student student1 = new Student(1, "Alice", "Female", 85);
        Student student2 = new Student(2, "Bob", "Male");

        System.out.println("Details of Student 1:");
        student1.display();

        System.out.println("\nDetails of Student 2:");
        student2.display();

        System.out.println("\nTotal number of students: " + Student.getCount());
    }
}
