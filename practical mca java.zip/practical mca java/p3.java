abstract class BankAccount {
    String accountHolder;
    double balance;
     
    void displayAccountDetails() {
        System.out.println("Account Holder: " + accountHolder);
        System.out.println("Balance: " + balance);
    }

    abstract void calculateInterest();
}

class SavingsAccount extends BankAccount {
    SavingsAccount(String accountHolder, double balance) {
        this.accountHolder = accountHolder;
        this.balance = balance;
    }

    void calculateInterest() {
        System.out.println("Interest on Savings Account: " + (balance * 0.04));
    }
}

class CurrentAccount extends BankAccount {
    CurrentAccount(String accountHolder, double balance) {
        this.accountHolder = accountHolder;
        this.balance = balance;
    }

    void calculateInterest() {
        System.out.println("Interest on Current Account: " + (balance * 0.02));
    }
}


public class p3 {
    public static void main(String[] args) {

        BankAccount savings = new SavingsAccount("John", 5000);
        BankAccount current = new CurrentAccount("Jane", 3000);

        // Display details and interest
        savings.calculateInterest();
        savings.displayAccountDetails();

        System.out.println();  

        current.calculateInterest();
        current.displayAccountDetails();
    }
}
