import java.util.ArrayList;
import java.util.Scanner;

public class p1ArrayList {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<String> names = new ArrayList<>();

        // Input names
        System.out.println("Enter 5 names:");
        for (int i = 0; i < 5; i++) {
            System.out.print("Enter name: ");
            names.add(sc.nextLine());
        }

        // Display names
        System.out.println("Names: " + names);

        // Search for a name
        System.out.print("Enter name to search: ");
        String searchName = sc.nextLine();
        if (names.contains(searchName)) {
            System.out.println(searchName + " is at position " + names.indexOf(searchName));
        } else {
            System.out.println(searchName + " is not in the list.");
        }

        // Add a name
        System.out.print("Enter a new name to add: ");
        names.add(sc.nextLine());
        System.out.println("Updated list: " + names);

        // Update the third name
        if (names.size() >= 3) {
            System.out.println("Current third name: ");
            String nm= sc.nextLine();
            names.set(2, nm);
            System.out.println("After updating the third name: " + names);
        }

        // Remove the fourth name
        if (names.size() >= 4) {
            names.remove(3);
            System.out.println("After removing the fourth name: " + names);
        }

        // Display all names
        System.out.println("All names:");
        for (int i = 0; i < names.size(); i++) {
            System.out.println(names.get(i));
        }

        sc.close();
    }
}
